package com.romero.gabriel.petagram;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;

import com.romero.gabriel.petagram.adapter.MascotaAdapter;
import com.romero.gabriel.petagram.pojo.Mascota;

import java.util.ArrayList;
import java.util.Collections;

public class MascotaFavoritaActivity extends AppCompatActivity {
    Toolbar actionBar;
    RecyclerView rvMascotas;
    ArrayList<Mascota> mascotas;
    ArrayList<Mascota> mascotasOrdenMeGusta;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mascota_favorita);

        actionBar = (Toolbar) findViewById(R.id.actionBar);
        setSupportActionBar(actionBar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        rvMascotas = (RecyclerView) findViewById(R.id.rvMascotas);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvMascotas.setLayoutManager(linearLayoutManager);

        inicializarMascotas();
        inicializarAdapter();
    }

    private void inicializarAdapter() {
        MascotaAdapter mascotaAdapter = new MascotaAdapter(mascotasOrdenMeGusta);
        rvMascotas.setAdapter(mascotaAdapter);
    }

    private void inicializarMascotas() {
        mascotas = new ArrayList<Mascota>();
        mascotasOrdenMeGusta = new ArrayList<Mascota>();

        mascotas.add(new Mascota(getResources().getString(R.string.string_alita),R.drawable.img_alita,3));
        mascotas.add(new Mascota(getResources().getString(R.string.string_conejito),R.drawable.img_conejito,10));
        mascotas.add(new Mascota(getResources().getString(R.string.string_espanto),R.drawable.img_espanto,4));
        mascotas.add(new Mascota(getResources().getString(R.string.string_lanudo),R.drawable.img_lanudo,6));
        mascotas.add(new Mascota(getResources().getString(R.string.string_mem),R.drawable.img_mem,7));
        mascotas.add(new Mascota(getResources().getString(R.string.string_mike),R.drawable.img_mike,8));
        mascotas.add(new Mascota(getResources().getString(R.string.string_pancita),R.drawable.img_pancita,8));
        mascotas.add(new Mascota(getResources().getString(R.string.string_ronny),R.drawable.img_ronny,9));
        mascotas.add(new Mascota(getResources().getString(R.string.string_salchichita),R.drawable.img_salchicha,9));

        Collections.sort(mascotas, Mascota.SortByMeGusta);

        for(int n=0;n<=4;n++){
            mascotasOrdenMeGusta.add(mascotas.get(n));
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_HOME){
            if (keyCode == KeyEvent.KEYCODE_HOME){
                intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
            }
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }
}
