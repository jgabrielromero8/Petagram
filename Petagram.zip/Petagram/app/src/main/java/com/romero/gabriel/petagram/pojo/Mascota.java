package com.romero.gabriel.petagram.pojo;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Comparator;

/**
 * Created by IMPI-Gabo on 04/08/2017.
 */

public class Mascota implements Parcelable {
    private String  nombre;
    private int     foto;
    private int  meGusta;

    public Mascota(String nombre, int foto, int meGusta) {
        this.nombre = nombre;
        this.foto = foto;
        this.meGusta = meGusta;
    }

    protected Mascota(Parcel in) {
        nombre = in.readString();
        foto = in.readInt();
        meGusta = in.readInt();
    }

    /*Comparator for sorting the list by MeGusta no*/
    public static Comparator<Mascota> SortByMeGusta = new Comparator<Mascota>() {

        public int compare(Mascota m1, Mascota m2) {

            int meGusta1 = m1.getMeGusta();
            int meGusta2 = m2.getMeGusta();

	   /*For ascending order*/
            //return meGusta1-meGusta2;

	   /*For descending order*/
            return meGusta2-meGusta1;
        }};



    public static final Creator<Mascota> CREATOR = new Creator<Mascota>() {
        @Override
        public Mascota createFromParcel(Parcel in) {
            return new Mascota(in);
        }

        @Override
        public Mascota[] newArray(int size) {
            return new Mascota[size];
        }
    };

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    public int getMeGusta() {
        return meGusta;
    }

    public void setMeGusta(int meGusta) {
        this.meGusta = meGusta;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(nombre);
        parcel.writeInt(foto);
        parcel.writeInt(meGusta);
    }

}
