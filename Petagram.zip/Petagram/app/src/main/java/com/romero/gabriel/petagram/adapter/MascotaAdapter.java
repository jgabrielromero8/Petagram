package com.romero.gabriel.petagram.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.romero.gabriel.petagram.R;
import com.romero.gabriel.petagram.pojo.Mascota;

import java.util.ArrayList;

/**
 * Created by IMPI-Gabo on 04/08/2017.
 */

public class MascotaAdapter extends RecyclerView.Adapter<MascotaAdapter.MascotaViewHolder> {
    ArrayList<Mascota> mascotas;

    public MascotaAdapter(ArrayList<Mascota> mascotas) {
        this.mascotas = mascotas;
    }

    @Override
    public MascotaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_mascota, parent, false);
        return new MascotaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final MascotaViewHolder holder, int position) {
        final Mascota mascota = mascotas.get(position);

        holder.ivFoto.setImageResource(mascota.getFoto());
        holder.tvNombre.setText(mascota.getNombre());
        holder.tvMeGusta.setText(Integer.toString(mascota.getMeGusta()));

        holder.ibHuesoBlanco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mascota.setMeGusta(mascota.getMeGusta() + 1);
                holder.tvMeGusta.setText(Integer.toString(mascota.getMeGusta()));
                Toast.makeText(v.getContext(),"+1 Me Gusta " + mascota.getNombre(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return mascotas.size();
    }

    //Despues de generar la clase se genera esta clase estática y luego se agrega el extends de la clase MascotaAdapter
    public static class MascotaViewHolder extends RecyclerView.ViewHolder {

        private ImageView   ivFoto;
        private TextView    tvNombre;
        private TextView    tvMeGusta;
        private ImageButton ibHuesoBlanco;

        public MascotaViewHolder(View itemView) {
            super(itemView);
                ivFoto          = (ImageView) itemView.findViewById(R.id.ivFoto);
                tvNombre        = (TextView) itemView.findViewById(R.id.tvNombre);
                tvMeGusta       = (TextView) itemView.findViewById(R.id.tvMeGusta);
                ibHuesoBlanco   = (ImageButton) itemView.findViewById(R.id.ibHuesoBlan);
        }
    }
}
