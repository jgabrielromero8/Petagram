package com.gabo.petagram;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import com.gabo.petagram.adapter.MascotaAdapter;
import com.gabo.petagram.pojo.Mascota;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Toolbar actionBar;
    RecyclerView rvMascotas;
    ArrayList<Mascota> mascotas;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        actionBar = (Toolbar) findViewById(R.id.actionBar);
        setSupportActionBar(actionBar);

        rvMascotas = (RecyclerView) findViewById(R.id.rvMascotas);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvMascotas.setLayoutManager(linearLayoutManager);

        inicializarMascotas();
        inicializarAdapter();
    }

    private void inicializarMascotas() {
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota(getResources().getString(R.string.string_alita), R.drawable.img_alita, 3));
        mascotas.add(new Mascota(getResources().getString(R.string.string_conejito), R.drawable.img_conejito, 10));
        mascotas.add(new Mascota(getResources().getString(R.string.string_espanto), R.drawable.img_espanto, 4));
        mascotas.add(new Mascota(getResources().getString(R.string.string_lanudo), R.drawable.img_lanudo, 6));
        mascotas.add(new Mascota(getResources().getString(R.string.string_mem), R.drawable.img_mem, 7));
        mascotas.add(new Mascota(getResources().getString(R.string.string_mike), R.drawable.img_mike, 8));
        mascotas.add(new Mascota(getResources().getString(R.string.string_pancita), R.drawable.img_pancita, 8));
    }

    private void inicializarAdapter() {
        MascotaAdapter mascotaAdapter = new MascotaAdapter(mascotas);
        rvMascotas.setAdapter(mascotaAdapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_fav:
                intent = new Intent(this,MascotaFavoritaActivity.class);
                intent.putExtra("mascotas",mascotas);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_favoritos,menu);
        return super.onCreateOptionsMenu(menu);
    }
}
